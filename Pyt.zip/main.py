multiplication = 15 * 3
division  = 15 / 3
division_without_remainder = 15 // 2
degree = 15 ** 2

print(f'multiplication = {type(multiplication)}\n'
      f'division = {type(division)}\n'
      f'division_without_remainder = {type(division_without_remainder)}\n'
      f'degree = {type(degree)}\n'
      )