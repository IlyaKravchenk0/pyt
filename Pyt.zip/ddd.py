test = ['в', '5', 'часов', '17', 'минут', 'температура', 'воздуха', 'была', '+5', 'градусов']
test[8] = 5
print(
    f'My massiv {test}, \n'
    f'{test[0]} "0{test[1]}" {test[2]} "{test[3]}" {test[4]} {test[5]} {test[6]} {test[7]} "+0{test[8]}" {test[9]}'
)

